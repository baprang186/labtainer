from Crypto.Util.number import *
import base64
messages = b'V2VsY29tZSB0byB0aGUgd2llbmVyIGxhYg=='

def encrypt(message, e, n):
    # Encrypt message
    return pow(message, e, n)
# Generate random p, q
p = getPrime(256) 
q = getPrime(256)

# Generate random d 
d = getPrime(120)

# Calc Euler's Totient function
n = p * q   
phi_n = (p - 1) * (q - 1)  

# Choose e while 1 < e < phi_n and gcd(e, phi_n) = 1
e = inverse(d, phi_n)
c_messages = base64.b64decode(messages)
m = bytes_to_long(c_messages)
print(f"Public Key (e, n): ({e}, {n})")

c = encrypt(m, e, n)
print("Ciphertext:", c)
